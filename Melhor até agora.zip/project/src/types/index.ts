export interface Cliente {
  id?: string;
  nome: string;
  telefone: string;
}

export interface Servico {
  id?: string;
  clienteId: string;
  tipo: string;
  equipamento: string;
  valor: number;
  statusPagamento: 'Pendente' | 'Pago';
  data: string;
  dizimo?: number;
}

export interface User {
  id: string;
  email: string;
}