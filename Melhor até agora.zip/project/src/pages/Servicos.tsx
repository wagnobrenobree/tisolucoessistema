import React from 'react';
import { collection, addDoc, getDocs, deleteDoc, doc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Servico, Cliente } from '../types';
import { Pencil, Trash2 } from 'lucide-react';

export function Servicos() {
  const [servicos, setServicos] = React.useState<Servico[]>([]);
  const [clientes, setClientes] = React.useState<Cliente[]>([]);
  const [servicoEditando, setServicoEditando] = React.useState<Servico | null>(null);
  const [formData, setFormData] = React.useState({
    clienteId: '',
    tipo: '',
    equipamento: '',
    valor: '',
    statusPagamento: 'Pendente',
    data: new Date().toISOString().split('T')[0],
  });

  const carregarDados = async () => {
    const [servicosSnapshot, clientesSnapshot] = await Promise.all([
      getDocs(collection(db, 'servicos')),
      getDocs(collection(db, 'clientes')),
    ]);

    const servicosData = servicosSnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Servico[];

    const clientesData = clientesSnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data()
    })) as Cliente[];

    setServicos(servicosData);
    setClientes(clientesData);
  };

  React.useEffect(() => {
    carregarDados();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    const servicoData = {
      ...formData,
      valor: Number(formData.valor),
      dizimo: formData.statusPagamento === 'Pago' ? Number(formData.valor) * 0.1 : 0,
    };

    if (servicoEditando) {
      await updateDoc(doc(db, 'servicos', servicoEditando.id!), servicoData);
    } else {
      await addDoc(collection(db, 'servicos'), servicoData);
    }

    setFormData({
      clienteId: '',
      tipo: '',
      equipamento: '',
      valor: '',
      statusPagamento: 'Pendente',
      data: new Date().toISOString().split('T')[0],
    });
    setServicoEditando(null);
    carregarDados();
  };

  const handleEditar = (servico: Servico) => {
    setServicoEditando(servico);
    setFormData({
      clienteId: servico.clienteId,
      tipo: servico.tipo,
      equipamento: servico.equipamento,
      valor: servico.valor.toString(),
      statusPagamento: servico.statusPagamento,
      data: servico.data,
    });
  };

  const handleExcluir = async (id: string) => {
    if (window.confirm('Tem certeza que deseja excluir este serviço?')) {
      await deleteDoc(doc(db, 'servicos', id));
      carregarDados();
    }
  };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold text-gray-900">Serviços</h1>

      <form onSubmit={handleSubmit} className="bg-white shadow rounded-lg p-6">
        <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
          <div>
            <label htmlFor="cliente" className="block text-sm font-medium text-gray-700">
              Cliente
            </label>
            <select
              id="cliente"
              required
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              value={formData.clienteId}
              onChange={(e) => setFormData({ ...formData, clienteId: e.target.value })}
            >
              <option value="">Selecione um cliente</option>
              {clientes.map((cliente) => (
                <option key={cliente.id} value={cliente.id}>
                  {cliente.nome}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label htmlFor="tipo" className="block text-sm font-medium text-gray-700">
              Tipo de Serviço
            </label>
            <input
              type="text"
              id="tipo"
              required
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              value={formData.tipo}
              onChange={(e) => setFormData({ ...formData, tipo: e.target.value })}
            />
          </div>

          <div>
            <label htmlFor="equipamento" className="block text-sm font-medium text-gray-700">
              Equipamento
            </label>
            <input
              type="text"
              id="equipamento"
              required
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              value={formData.equipamento}
              onChange={(e) => setFormData({ ...formData, equipamento: e.target.value })}
            />
          </div>

          <div>
            <label htmlFor="valor" className="block text-sm font-medium text-gray-700">
              Valor
            </label>
            <input
              type="number"
              id="valor"
              required
              step="0.01"
              min="0"
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              value={formData.valor}
              onChange={(e) => setFormData({ ...formData, valor: e.target.value })}
            />
          </div>

          <div>
            <label htmlFor="status" className="block text-sm font-medium text-gray-700">
              Status do Pagamento
            </label>
            <select
              id="status"
              required
              className="mt-1 block w-full border border- gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              value={formData.statusPagamento}
              onChange={(e) => setFormData({ ...formData, statusPagamento: e.target.value as 'Pendente' | 'Pago' })}
            >
              <option value="Pendente">Pendente</option>
              <option value="Pago">Pago</option>
            </select>
          </div>

          <div>
            <label htmlFor="data" className="block text-sm font-medium text-gray-700">
              Data do Serviço
            </label>
            <input
              type="date"
              id="data"
              required
              className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
              value={formData.data}
              onChange={(e) => setFormData({ ...formData, data: e.target.value })}
            />
          </div>
        </div>

        <div className="mt-6">
          <button
            type="submit"
            className="w-full md:w-auto px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500"
          >
            {servicoEditando ? 'Atualizar Serviço' : 'Cadastrar Serviço'}
          </button>
        </div>
      </form>

      <div className="bg-white shadow rounded-lg overflow-hidden">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Cliente
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Tipo
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Equipamento
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Valor
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Data
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Ações
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {servicos.map((servico) => {
              const cliente = clientes.find(c => c.id === servico.clienteId);
              return (
                <tr key={servico.id}>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {cliente?.nome}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {servico.tipo}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {servico.equipamento}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {new Intl.NumberFormat('pt-BR', {
                      style: 'currency',
                      currency: 'BRL'
                    }).format(servico.valor)}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      servico.statusPagamento === 'Pago'
                        ? 'bg-green-100 text-green-800'
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {servico.statusPagamento}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                    {new Date(servico.data).toLocaleDateString('pt-BR')}
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium">
                    <button
                      onClick={() => handleEditar(servico)}
                      className="text-blue-600 hover:text-blue-900 mr-4"
                    >
                      <Pencil size={20} />
                    </button>
                    <button
                      onClick={() => handleExcluir(servico.id!)}
                      className="text-red-600 hover:text-red-900"
                    >
                      <Trash2 size={20} />
                    </button>
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>
    </div>
  );
}