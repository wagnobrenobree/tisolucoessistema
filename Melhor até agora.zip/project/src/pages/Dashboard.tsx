import React from 'react';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Servico } from '../types';
import { format } from 'date-fns';
import { ptBR } from 'date-fns/locale';

export function Dashboard() {
  const [mesSelecionado, setMesSelecionado] = React.useState(() => {
    const hoje = new Date();
    return `${hoje.getFullYear()}-${String(hoje.getMonth() + 1).padStart(2, '0')}`;
  });
  const [indicadores, setIndicadores] = React.useState({
    totalFaturado: 0,
    totalRecebido: 0,
    pagamentosPendentes: 0,
    quantidadeServicos: 0,
    dizimo: 0,
  });

  React.useEffect(() => {
    const carregarDados = async () => {
      const [ano, mes] = mesSelecionado.split('-');
      const inicioPeriodo = new Date(Number(ano), Number(mes) - 1, 1);
      const fimPeriodo = new Date(Number(ano), Number(mes), 0);

      const servicosRef = collection(db, 'servicos');
      const q = query(
        servicosRef,
        where('data', '>=', inicioPeriodo.toISOString()),
        where('data', '<=', fimPeriodo.toISOString())
      );

      const querySnapshot = await getDocs(q);
      const servicos = querySnapshot.docs.map(doc => ({
        id: doc.id,
        ...doc.data()
      })) as Servico[];

      const totalFaturado = servicos.reduce((acc, servico) => acc + servico.valor, 0);
      const servicosPagos = servicos.filter(servico => servico.statusPagamento === 'Pago');
      const totalRecebido = servicosPagos.reduce((acc, servico) => acc + servico.valor, 0);
      const dizimo = totalRecebido * 0.1;

      setIndicadores({
        totalFaturado,
        totalRecebido,
        pagamentosPendentes: totalFaturado - totalRecebido,
        quantidadeServicos: servicos.length,
        dizimo,
      });
    };

    carregarDados();
  }, [mesSelecionado]);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <input
          type="month"
          value={mesSelecionado}
          onChange={(e) => setMesSelecionado(e.target.value)}
          className="border border-gray-300 rounded-md shadow-sm px-4 py-2"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900">Total Faturado</h3>
          <p className="mt-2 text-3xl font-bold text-blue-600">
            {new Intl.NumberFormat('pt-BR', {
              style: 'currency',
              currency: 'BRL'
            }).format(indicadores.totalFaturado)}
          </p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900">Total Recebido</h3>
          <p className="mt-2 text-3xl font-bold text-green-600">
            {new Intl.NumberFormat('pt-BR', {
              style: 'currency',
              currency: 'BRL'
            }).format(indicadores.totalRecebido)}
          </p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900">Pagamentos Pendentes</h3>
          <p className="mt-2 text-3xl font-bold text-red-600">
            {new Intl.NumberFormat('pt-BR', {
              style: 'currency',
              currency: 'BRL'
            }).format(indicadores.pagamentosPendentes)}
          </p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900">Quantidade de Serviços</h3>
          <p className="mt-2 text-3xl font-bold text-gray-900">
            {indicadores.quantidadeServicos}
          </p>
        </div>

        <div className="bg-white rounded-lg shadow p-6">
          <h3 className="text-lg font-medium text-gray-900">Dízimo Calculado</h3>
          <p className="mt-2 text-3xl font-bold text-purple-600">
            {new Intl.NumberFormat('pt-BR', {
              style: 'currency',
              currency: 'BRL'
            }).format(indicadores.dizimo)}
          </p>
        </div>
      </div>
    </div>
  );
}