import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyBQNUC3O4JhjfLjwBMy2Lw3Hqw_Qi3ggig",
  authDomain: "agoravai-4a70e.firebaseapp.com",
  projectId: "agoravai-4a70e",
  storageBucket: "agoravai-4a70e.firebasestorage.app",
  messagingSenderId: "481326314735",
  appId: "1:481326314735:web:6cc94f786c590ceb3a571a"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);